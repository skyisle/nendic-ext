/**
 * Naver English Dictionary Chrome Extension
 * Background Script
 *
 * @author ohgyun@gmail.com
 */
var NendicExt = (function () {

  var __parser = null;

  function createContextMenu() {
    chrome.contextMenus.create({
      "title": "네이버 영어사전에서 '%s' 검색",
      "contexts": ["selection"],
      "onclick": function (info) {
        searchWord(info.selectionText);
      }
    });
  }
  
  function searchWord(query) {
    var url = "http://endic.naver.com/searchAssistDict.nhn?query=" + query;
    $.ajax({
      url: url,
      crossDomain: false, // chrome extension makes request to same domain
      dataType: "html", // searched result is html type
      success: function (data) {
        showResult(data, query);
      }
    });
  }

  function showResult(data, query) {
    var parsedData = __parser.parse(data);
    parsedData.query = query;
    
    chrome.tabs.getSelected(null, function (tab) {
      chrome.tabs.sendRequest(tab.id, {
        "command": "showResult",
        "data": parsedData
      });
    });
  }

  /**
   * 여러 개의 프레임이 나뉘어진 페이지의 경우,
   * 다른 프레임을 클릭하면 현재 프레임의 레이어가 닫기지 않는 문제가 있다.
   * close event를 익스텐션에서 전체 페이지에 던지는 방식으로 구현한다.
   */
  function bindCloseEventListener() {
	chrome.extension.onRequest.addListener(
	  function (request, sender, sendResponse) {
	    chrome.tabs.getSelected(null, function (tab) {
		  chrome.tabs.sendRequest(tab.id, {
			"command": "close"
		  });
		});
	    
	    sendResponse({});
	  }
	);
  }
  
  return {
    initialize: function () {
      createContextMenu();
      bindCloseEventListener();
    },
    setParser: function (parser) {
      __parser = parser;
    },
    searchWord: function (query) {
      searchWord(query);
    }
  };

}()); 

