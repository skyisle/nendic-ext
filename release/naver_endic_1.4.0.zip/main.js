/*
 * initialize modules
 */
NendicExt.initialize();
DicParser.initialize();

NendicExt.setParser(DicParser);

