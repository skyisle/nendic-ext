/**
 * Naver English Dictionary Chrome Extension
 * Background Script
 *
 * @author ohgyun@gmail.com
 */
var NendicExt = (function () {

  var __parser = null,
    _recentQuery = "";

  function createContextMenu() {
    chrome.contextMenus.create({
      "title": "네이버 영어사전에서 '%s' 검색",
      "contexts": ["selection"],
      "onclick": function (info) {
        searchWord(info.selectionText);
      }
    });
  }
  
  function searchWord(query) {
    var url = "http://endic.naver.com/searchAssistDict.nhn?query=" + query;
    _recentQuery = query;
    
    $.ajax({
      url: url,
      crossDomain: false, // chrome extension makes request to same domain
      dataType: "html", // searched result is html type
      success: function (data) {
        showResult(data, query);
      }
    });
  }

  function showResult(data, query) {
    var parsedData = __parser.parse(data);
    parsedData.query = query;
    
    chrome.tabs.getSelected(null, function (tab) {
      chrome.tabs.sendRequest(tab.id, {
        "command": "showResult",
        "data": parsedData
      });
    });
  }

  /**
   * 여러 개의 프레임이 나뉘어진 페이지의 경우,
   * 다른 프레임을 클릭하면 현재 프레임의 레이어가 닫기지 않는 문제가 있다.
   * close event를 익스텐션에서 전체 페이지에 던지는 방식으로 구현한다.
   */
  function bindRequestEventListener() {
	chrome.extension.onRequest.addListener(
	  function (request, sender, sendResponse) {
	    var command = request.command,
	      data = request.data;
        
        if (command) {
	      doAction(command, data);
        }
	    
	    sendResponse({});
	  }
	);
  }
  
  function doAction(command, data) {
    var action = NendicExt.action[command];
    if (typeof action === "function") {
      action(data);
    }
  }
  
  return {
    initialize: function () {
      createContextMenu();
      bindRequestEventListener();
    },
    setParser: function (parser) {
      __parser = parser;
    },
    searchWord: function (query) {
      searchWord(query);
    },
    searchWordWithRecentQuery: function () {
      searchWord(_recentQuery);
    }
  };

}()); 

NendicExt.action = {
  "close": function (data) {
    chrome.tabs.getSelected(null, function (tab) {
	  chrome.tabs.sendRequest(tab.id, {
	    "command": "close"
      });
    });      
  },
  
  /**
   * 한영/영영 사전을 전환한다.
   * 쿠키에 isOnlyViewEE 값을 Y로 설정하면 영영사전으로 응답이 온다.
   */
  "toggleDicType": function (data) {
    var url = "http://endic.naver.com/searchAssistDict.nhn",
      cookieName = "isOnlyViewEE";
    
    // 1. 쿠키를 가져오는 것이 완료되면, 
    chrome.cookies.get({
      "url": url,
      "name": cookieName
      
    }, function (cookie) {
      // 2. 쿠기값을 확인해 변경할 값을 정하고,
      var toggledValue;
      
      if (cookie === null || cookie.value === "N") {
        toggledValue = "Y";
      } else {
    	toggledValue = "N";
      }
      
      // 3. 선택된 쿠키를 삭제한 후, (fix: Mac OS에서 쿠키가 삭제되지 않고 append 되는 문제)
      chrome.cookies.remove({
    	"url": url,
        "name": cookieName,
      }, function () {
        // 4. 쿠키를 다시 셋팅하고 검색 요청을 보낸다.
        chrome.cookies.set({
    	  "url": url,
    	  "name": cookieName,
    	  "value": toggledValue
    	}, function (cookie) {
    	  NendicExt.searchWordWithRecentQuery();
    	});
      });
      
    });
  },
  
  "search": function (data) {
    NendicExt.searchWord(data);
  }
};
