/**
 * Naver English Dictionary Chrome Extention
 * Content Script
 *
 * @author ohgyun@gmail.com
 */
var NendicExt = (function () {

  var _isPageActivated = false; // 사용자가 현재 페이지를 보고 있는가?

  function bindExtensionRequestListener() {
    chrome.extension.onRequest.addListener(
      function (request, sender, sendResponse) {
        var command = request.command,
          data = request.data;

        if (_isPageActivated && command) {
          doAction(command, data);
        }

        sendResponse({});
      }
    );
  }

  function doAction(command, data) {
    var action = NendicExt.action[command];
    if (typeof action === "function") {
      action(data);
    }
  }

  return {
    initialize: function () {
      bindExtensionRequestListener();
    },
    activatePage: function () {
      _isPageActivated = true;
    }
  };

}());

NendicExt.action = {
  "showResult": function (data) {
    NendicExt.ui.open(data);
  },
  
  "close": function (data) {
  	NendicExt.ui.close();
  }
};

NendicExt.ui = (function () {

  var _wrapper = null,
    _wrapperId = "endic_ext_wrapper";

  function createWrapperElement() {
    var el = document.createElement("div");
    el.id = _wrapperId;

    document.body.appendChild(el);

    _wrapper = el;
  }

  function bindPageActivateEvent() {
    // 사용자가 body를 클릭했으면, 페이지를 사용하고 있다고 판단한다.
    // click 이벤트보다 먼저 발생해야 한다. 
    document.body.addEventListener("mousedown", function (evt) {
      NendicExt.activatePage();
    }, false);
  }

  /**
   * 여러 개의 프레임으로 나뉘어진 페이지의 경우,
   * 다른 프레임을 클릭하면 현재 프레임의 레이어가 닫기지 않는 문제가 있다.
   * close event를 익스텐션에서 전체 페이지에 던지는 방식으로 구현한다.
   */
  function bindRequestCloseEvent() {
    document.body.addEventListener("click", function (evt) {
      if (isChildOfWrapper(evt.target)) {
	  	delegateWrapperEvent(evt.target);
        return;
      }

      chrome.extension.sendRequest({"command": "close"});
    }, false);
  }

  function isChildOfWrapper(target) {
    var depth = 5, // endic's max depth is 5
      parent = target;

    for (var i = 0; i < depth; i++) {
	  try {
	  	// parent가 body 일 경우 ReferenceError가 발생한다. 이 경우, false를 리턴한다.
        parent = parent.parentNode;
	  } catch (e) {
	    return false;  
	  }
	  
      if (parent && parent.id === _wrapperId) {
        return true;
      }
    }

    return false;
  }
  
  /**
   * wrapper 엘리먼트에 delegate로 할당된 이벤트를 처리한다.
   */
  function delegateWrapperEvent(target) {
    var listener = NendicExt.ui.delegated[target.id];
	if (typeof listener === "function") {
	  listener(target);
	}  	
  }
  
  /**
   * 키워드 검색을 위한 단축키를 할당한다.
   */
  function bindShortcutEvent() {
  	NendicExt.ui.shortcut.bind();
  }
  
  function open(data) {
  	if (data) {
      var html = NendicExt.tmpl(NendicExt.markup, data);
      _wrapper.innerHTML = html;
	}
    _wrapper.style.display = "block";
  }

  function close() {
    _wrapper.style.display = "none";
    _wrapper.innerHTML = "";
  }

  return {
    initialize: function () {
      createWrapperElement();
      bindPageActivateEvent();
      bindRequestCloseEvent();
	  bindShortcutEvent();
    },

    open: function (data) {
      open(data);
    },

    isOpened: function () {
	  return _wrapper.style.display === "block";
	},

    close: function () {
      close();
    }
  };

}());

/**
 * wrapper 내 컨텐츠에 delegate 이벤트를 할당한다.
 * key 값을 엘리먼트의 id를 사용한다.
 */
NendicExt.ui.delegated = {
  "endic_ext_toggle_dic_type_btn": function (target) {
  	chrome.extension.sendRequest({"command": "toggleDicType"});
  }
};

/**
 * 검색 단축키를 설정한다.
 */
NendicExt.ui.shortcut = (function () {
  
  var _doing = false,
    _timeLimit = 1000,
  	_timer = null;
  
  function bindKeyEvent() {
  	document.body.addEventListener("keydown", function (evt) {
	  switch (evt.keyCode) {
	  case 70: // f
	  case 68: // d
	    process(evt.keyCode);
		break;
	
	  case 27: // esc
	    close();
		break;
		
	  case 83: // s
	    switchDicType();
		break;
	  }
	  
	});
  }
  
  function isValidKey(evt) {
  	// f or d(means find dictionary)
  	return evt.keyCode === 70 || evt.keyCode === 68;
  }
  
  /**
   * 텍스트를 선택하고, fd 키를 연속으로 클릭하면 검색을 시도한다. 
   * fd means find dictionary
   */
  function process(keyCode) {
  	if (_doing === false && keyCode === 70) { // 최초에 f 키를 누른다.
	  _doing = true;
	  
	  _timer = setTimeout(function () {
	  	_doing = false;
		_timer = null;
	  }, _timeLimit);
	}
	
	if (_doing === true && keyCode === 68) { // 연속으로 d 키를 누른다.
	  _doing = false;
	  
	  var selectionText = getSelectedText();
	  if (selectionText) {
		chrome.extension.sendRequest({"command": "search", "data": selectionText});
	  }
	  
	  if (_timer) {
	  	clearTimeout(_timer);
		_timer = null;
	  }
	}
  }
  
  function getSelectedText() {
  	return window.getSelection().toString().trim();
  }

  function close() {
  	if (NendicExt.ui.isOpened()) {
  	  chrome.extension.sendRequest({"command": "close"});
	}
  }
  
  function switchDicType() {
  	if (NendicExt.ui.isOpened()) {
  	  chrome.extension.sendRequest({"command": "toggleDicType"});
	}
  }

  return {
    bind: function () {
	  bindKeyEvent();
	}  	
  };
}());


// Simple JavaScript Templating
// John Resig - http://ejohn.org/ - MIT Licensed
NendicExt.tmpl = (function(){
  var cache = {};
  
  var tmpl = function tmpl(str, data){
    // Figure out if we're getting a template, or if we need to
    // load the template - and be sure to cache the result.
    var fn = !/\W/.test(str) ?
      cache[str] = cache[str] || tmpl(str) :
      
      // Generate a reusable function that will serve as a template
      // generator (and which will be cached).
      new Function("obj",
        "var p=[],print=function(){p.push.apply(p,arguments);};" +
        
        // Introduce the data as local variables using with(){}
        "with(obj){p.push('" +
        
        // Convert the template into pure JavaScript
        str
          .replace(/[\r\t\n]/g, " ")
          .split("<%").join("\t")
          .replace(/((^|%>)[^\t]*)'/g, "$1\r")
          .replace(/\t=(.*?)%>/g, "',$1,'")
          .split("\t").join("');")
          .split("%>").join("p.push('")
          .split("\r").join("\\'")
      + "');}return p.join('');");
    
    // Provide some basic currying to the user
    return data ? fn( data ) : fn;
  };

  return tmpl;

})();


NendicExt.markup = [
  // header
  '<div id="endic_ext_header">',
    '<div class="endic_ext_endic">',
      '<a class="endic_ext_endic_main" href="http://endic.naver.com" target="_blank">네이버 영어사전</a>',
    '</div>',
	
	// toggle ee dic button
	'<% if (result.length > 0) { %>',
	'<div class="endic_ext_toggle_dic_type">',
	  '<button id="endic_ext_toggle_dic_type_btn">한영/영영 전환</button>',
	'</div>',
	'<% } %>',
	// end toggle ee dic button
	
  '</div>',
  // end header

  // body
  '<div id="endic_ext_body">',
    // body wrapper
    '<div class="endic_ext_body_wrapper">',
	
    // words
    '<% for (var i = 0; i < result.length; i++) { %>',
      '<% var word = result[i]; %>',

      // word title
      '<h3>',
        '<strong><a href="<%= word.url %>" class="endic_ext_title" target="_blank"><%= word.title %></a></strong>',
        '<sup class="endic_ext_number"><%= word.number %></sup>',
        '<span class="endic_ext_phonetic_symbol"><%= word["phonetic_symbol"] %></span>',
      '</h3>',
      // end word title

      // word meanings
      '<% for (var j = 0; j < word.meanings.length; j++) { %>',
        '<% var meaning = word.meanings[j]; %>',

        // meaning
        '<div class="endic_ext_meaning">',
          '<h4 class="type"><%= meaning.type %></h4>',

          // meaning definitions
          '<% for (var k = 0; k < meaning.definitions.length; k++) { %>',
            '<% var definition = meaning.definitions[k]; %>',

            // definition
            '<div class="endic_ext_defs">',
              '<div class="endic_ext_definition"><%= definition.def %></div>',
              '<div class="endic_ext_ex_en"><%= definition["ex_en"] %></div>',
              '<div class="endic_ext_ex_kr"><%= definition["ex_kr"] %></div>',
            '</div>',
            // end definition

          '<% } %>',
          // end meaning definitions

          // more definition 
          '<% if (meaning.moreDefinition.count > 0) { %>',
            '<div class="endic_ext_moreDefinition">',
              '<a href="<%= meaning.moreDefinition.url %>" target="_blank"><%= meaning.moreDefinition.count %>개 뜻 더보기</a>',
            '</div>',
          '<% } %>',
          // end more definition

        '</div>',
        // end meaning

      '<% } %>',
      // end word meanings
    
    '<% } %>',
    // end words

    // if no result
    '<% if (result.length === 0) { %>',
      '<div class="endic_ext_noresult"><span class="endic_ext_keyword">\'<%= query %>\'</span>에 대한 검색 결과가 없습니다.</div>',
    '<% } %>',
    // end if no result

    '</div>',
    // end body wrapper
  
  '</div>',
  // end body

  // footer
  '<div id="endic_ext_footer"></div>'
  // end footer
].join("");


// initialize module
// content scripts of extention are inserted after DOM loaded.("document_idle")
NendicExt.initialize();
NendicExt.ui.initialize();
